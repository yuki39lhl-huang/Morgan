#!/usr/bin/env python3
"""
加密货币新闻抓取（免费方案）
📰 抓取 CoinDesk、Cointelegraph 等免费新闻
🧠 分析情绪（利好/利空）
📊 结合技术面给出综合建议
"""

import requests
import json
from pathlib import Path
from datetime import datetime, timezone, timedelta

# 新闻网站列表（免费 RSS/HTML）
NEWS_SOURCES = [
    {
        'name': 'CoinDesk',
        'url': 'https://www.coindesk.com/arc/outboundfeeds/rss/',
        'type': 'rss'
    },
    {
        'name': '金色财经',
        'url': 'https://www.jin10.com/rss_feed.html',
        'type': 'html'
    }
]

NEWS_FILE = Path("/root/.openclaw/workspace/scripts/crypto_news.json")
ANALYSIS_FILE = Path("/root/.openclaw/workspace/scripts/crypto_news_analysis.md")

# 情绪关键词
SENTIMENT_KEYWORDS = {
    'bullish': [
        '暴涨', '突破', '利好', '上涨', '买入', 'bull', 'moon', 'rally',
        'surge', 'jump', 'gain', 'rise', 'breakout', 'buy', 'upgrade'
    ],
    'bearish': [
        '暴跌', '崩盘', '利空', '下跌', '卖出', 'bear', 'crash', 'dump',
        'plunge', 'drop', 'fall', 'sell', 'hack', 'attack', 'ban'
    ],
    'neutral': [
        '震荡', '盘整', '观望', 'sideways', 'consolidation', 'regulation'
    ]
}

def get_beijing_time():
    return datetime.now(timezone.utc).astimezone(timezone(timedelta(hours=8)))

def log(msg):
    timestamp = get_beijing_time().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{timestamp}] {msg}")

def fetch_coindesk():
    """抓取 CoinDesk 新闻（直接 RSS + 代理）"""
    try:
        import xml.etree.ElementTree as ET
        
        # 直接抓取 RSS
        url = "http://www.coindesk.com/arc/outboundfeeds/rss/"
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(url, headers=headers, timeout=15, 
                              proxies={'http': 'http://127.0.0.1:7890', 'https': 'http://127.0.0.1:7890'})
        response.raise_for_status()
        
        # 解析 XML
        try:
            root = ET.fromstring(response.content)
            news_items = []
            
            for item in root.findall('.//item')[:10]:  # 最多 10 条
                title = item.find('title').text if item.find('title') is not None else ''
                link = item.find('link').text if item.find('link') is not None else ''
                pub_date = item.find('pubDate').text if item.find('pubDate') is not None else ''
                
                # 转换时间格式（UTC → 北京时间）
                try:
                    # 解析 RSS 时间格式：Wed, 11 Mar 2026 23:00:49 +0000
                    dt = datetime.strptime(pub_date, '%a, %d %b %Y %H:%M:%S %z')
                    # 转换为北京时间
                    dt_beijing = dt.astimezone(timezone(timedelta(hours=8)))
                    time_str = dt_beijing.strftime('%Y-%m-%d %H:%M')
                except:
                    time_str = pub_date
                
                news_items.append({
                    'title': title,
                    'url': link,
                    'time': time_str,
                    'content': ''
                })
            
            log(f"✅ CoinDesk 抓取成功：{len(news_items)} 条")
            return news_items
        except ET.ParseError as e:
            log(f"❌ XML 解析失败：{e}")
            return []
            
    except Exception as e:
        log(f"❌ CoinDesk 抓取失败：{e}")
        return []

def analyze_sentiment(text):
    """分析文本情绪"""
    text_lower = text.lower()
    
    bullish_count = sum(1 for kw in SENTIMENT_KEYWORDS['bullish'] if kw.lower() in text_lower)
    bearish_count = sum(1 for kw in SENTIMENT_KEYWORDS['bearish'] if kw.lower() in text_lower)
    neutral_count = sum(1 for kw in SENTIMENT_KEYWORDS['neutral'] if kw.lower() in text_lower)
    
    if bullish_count > bearish_count * 1.5:
        return 'bullish', '🟢 利好'
    elif bearish_count > bullish_count * 1.5:
        return 'bearish', '🔴 利空'
    else:
        return 'neutral', '⚪ 中性'

def generate_analysis(news_items, market_data=None):
    """生成新闻分析报告"""
    time_str = get_beijing_time().strftime("%Y-%m-%d %H:%M:%S")
    
    # 统计情绪
    sentiment_counts = {'bullish': 0, 'bearish': 0, 'neutral': 0}
    analyzed_news = []
    
    for news in news_items:
        sentiment, emoji = analyze_sentiment(news.get('title', '') + ' ' + news.get('content', ''))
        sentiment_counts[sentiment] += 1
        analyzed_news.append({
            'title': news.get('title', ''),
            'url': news.get('url', ''),
            'sentiment': sentiment,
            'emoji': emoji,
            'time': news.get('time', '')
        })
    
    # 综合情绪判断
    if sentiment_counts['bullish'] > sentiment_counts['bearish'] * 1.5:
        overall = "🟢 偏多"
    elif sentiment_counts['bearish'] > sentiment_counts['bullish'] * 1.5:
        overall = "🔴 偏空"
    else:
        overall = "⚪ 震荡"
    
    # 生成报告
    lines = [
        f"# 📰 加密货币新闻分析",
        f"",
        f"**生成时间：** {time_str}",
        f"",
        f"---",
        f"",
        f"## 📊 市场情绪统计",
        f"",
        f"| 情绪 | 数量 |",
        f"| :---: | :---: |",
        f"| 🟢 利好 | {sentiment_counts['bullish']} |",
        f"| 🔴 利空 | {sentiment_counts['bearish']} |",
        f"| ⚪ 中性 | {sentiment_counts['neutral']} |",
        f"",
        f"**整体情绪：** {overall}",
        f"",
        f"---",
        f"",
        f"## 📰 重要新闻",
        f"",
    ]
    
    for news in analyzed_news[:5]:  # 只显示前 5 条
        lines.append(f"{news['emoji']} **{news['title']}**")
        lines.append(f"   [链接]({news['url']})")
        lines.append("")
    
    # 结合技术面（如果有市场数据）
    if market_data:
        lines.extend([
            f"---",
            f"",
            f"## 📈 技术面结合",
            f"",
        ])
        
        for coin in market_data[:5]:
            symbol = coin.get('symbol', 'UNKNOWN')
            rsi = coin.get('rsi')
            change = coin.get('change_24h', 0)
            
            # 综合判断
            tech_signal = "⚪ 中性"
            if rsi and rsi < 30:
                tech_signal = "🟢 超卖"
            elif rsi and rsi > 70:
                tech_signal = "🔴 超买"
            
            lines.append(f"**{symbol}**: {tech_signal} (RSI: {rsi if rsi else '--'}, 24h: {change:+.2f}%)")
        
        lines.append("")
    
    # 操作建议
    lines.extend([
        f"---",
        f"",
        f"## 💡 综合建议",
        f"",
        f"⚠️ 仅供参考，请自行判断风险！",
        f"",
    ])
    
    content = "\n".join(lines)
    
    # 保存到文件
    with open(ANALYSIS_FILE, 'w') as f:
        f.write(content)
    
    # 保存原始新闻数据
    with open(NEWS_FILE, 'w') as f:
        json.dump({
            'timestamp': get_beijing_time().isoformat(),
            'news': analyzed_news,
            'sentiment_counts': sentiment_counts,
            'overall': overall
        }, f, indent=2, ensure_ascii=False)
    
    return content

def main():
    log("🚀 新闻抓取启动")
    
    # 抓取新闻
    all_news = []
    
    # CoinDesk
    coindesk_news = fetch_coindesk()
    all_news.extend(coindesk_news)
    
    # 如果没有新闻，用示例数据测试（带当前时间）
    if not all_news:
        log("⚠️ 无新闻数据，使用示例数据")
        now = get_beijing_time().strftime('%Y-%m-%d %H:%M')
        all_news = [
            {'title': 'Bitcoin Surges Past $70,000 as Institutional Adoption Grows', 'url': 'https://example.com/1', 'time': now},
            {'title': 'Ethereum Network Upgrade Successfully Completed', 'url': 'https://example.com/2', 'time': now},
            {'title': 'SEC Delays Decision on Crypto ETF Applications', 'url': 'https://example.com/3', 'time': now},
        ]
    
    # 生成分析报告
    analysis = generate_analysis(all_news)
    
    log("✅ 新闻分析完成")
    log(f"📄 报告已保存：{ANALYSIS_FILE}")
    
    # 输出报告内容
    print("\n" + "="*60)
    print(analysis)
    print("="*60 + "\n")

if __name__ == "__main__":
    main()
