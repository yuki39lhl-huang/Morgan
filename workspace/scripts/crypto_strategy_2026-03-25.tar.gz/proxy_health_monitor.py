#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
代理健康监控 - 单代理监控 + 告警 + PRoot DNS 自动重启
- 每 30 秒检查代理可用性
- 连续失败 3 次后告警
- 检测 PRoot DNS 解析错误自动重启 Hysteria
- 记录失败历史
"""

import requests
import json
import time
import subprocess
import socket
from datetime import datetime
from pathlib import Path

HEALTH_FILE = Path("/root/.openclaw/workspace/scripts/proxy_health.json")
LOG_FILE = Path("/root/.openclaw/workspace/scripts/proxy_monitor.log")
PROXY_URL = "http://127.0.0.1:7890"
CONTINUOUS_FAIL_THRESHOLD = 3
HYSTERIA_BINARY = "/usr/local/bin/hysteria"
HYSTERIA_CONFIG = "/root/.openclaw/workspace/scripts/hysteria.yaml"
HYSTERIA_LOG = "/tmp/hysteria.log"

def log(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_line = f"[{timestamp}] {msg}"
    print(log_line)
    try:
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(log_line + "\n")
    except:
        pass

def check_dns_resolution():
    """检查 DNS 解析是否正常（检测 PRoot DNS 错误）"""
    try:
        # 尝试解析代理服务器域名
        socket.gethostbyname('rb01.kunlun01.com')
        return True
    except socket.gaierror as e:
        error_msg = str(e).lower()
        # 检测典型的 PRoot DNS 错误
        if 'network is unreachable' in error_msg or 'temporary failure' in error_msg:
            log(f"🔴 检测到 PRoot DNS 解析错误：{e}")
            return False
        return False
    except Exception as e:
        log(f"⚠️ DNS 检查异常：{e}")
        return False

def restart_hysteria():
    """重启 Hysteria 代理服务"""
    log("🔄 开始重启 Hysteria 代理...")
    
    try:
        # 1. 杀掉旧进程
        subprocess.run(['pkill', '-9', 'hysteria'], capture_output=True, timeout=5)
        time.sleep(2)
        
        # 2. 启动新进程
        cmd = f"nohup {HYSTERIA_BINARY} client -c {HYSTERIA_CONFIG} > {HYSTERIA_LOG} 2>&1 &"
        subprocess.run(cmd, shell=True, capture_output=True, timeout=5)
        
        # 3. 等待启动
        time.sleep(5)
        
        # 4. 验证是否启动成功
        result = subprocess.run(['pgrep', '-f', 'hysteria'], capture_output=True, text=True)
        if result.returncode == 0:
            pid = result.stdout.strip()
            log(f"✅ Hysteria 重启成功（PID: {pid}）")
            return True
        else:
            log("❌ Hysteria 重启失败：进程未启动")
            return False
            
    except Exception as e:
        log(f"❌ Hysteria 重启异常：{e}")
        return False

def check_binance_via_proxy():
    """通过代理检查 Binance API"""
    try:
        proxies = {'https': PROXY_URL, 'http': PROXY_URL}
        response = requests.get('https://testnet.binancefuture.com/fapi/v1/time', 
                               proxies=proxies, timeout=5)
        return response.status_code == 200
    except Exception as e:
        return False

def load_health():
    if HEALTH_FILE.exists():
        with open(HEALTH_FILE, 'r') as f:
            return json.load(f)
    return {'continuous_failures': 0, 'total_failures': 0, 'last_ok': None}

def save_health(health):
    with open(HEALTH_FILE, 'w') as f:
        json.dump(health, f, indent=2)

def send_alert(message):
    """发送告警到飞书"""
    # 写告警文件
    alert_file = Path("/root/.openclaw/workspace/scripts/proxy_alert.txt")
    with open(alert_file, 'w', encoding='utf-8') as f:
        f.write(f"🚨 代理告警\n\n{message}\n\n时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    log(f"📢 告警已写入：{alert_file}")

def main():
    health = load_health()
    
    log("=" * 60)
    log("🌐 代理健康监控启动（PRoot DNS 自动重启版）")
    log(f"目标代理：{PROXY_URL}")
    log(f"告警阈值：连续{CONTINUOUS_FAIL_THRESHOLD}次失败")
    log("🔧 新增功能：PRoot DNS 错误自动重启 Hysteria")
    log("=" * 60)
    
    while True:
        try:
            # 1. 先检查 DNS 解析
            dns_ok = check_dns_resolution()
            
            if not dns_ok:
                log("🔴 DNS 解析失败，尝试自动重启 Hysteria...")
                restart_success = restart_hysteria()
                
                if restart_success:
                    log("✅ DNS 自动重启完成，等待 30 秒后验证...")
                    time.sleep(30)
                    # 重启后继续下一轮检查
                    continue
                else:
                    log("❌ DNS 自动重启失败，发送告警...")
                    msg = f"""🔴 PRoot DNS 解析错误 + Hysteria 重启失败！

错误类型：DNS 无法解析代理服务器域名
自动重启：失败

可能原因：
1. PRoot 容器网络限制
2. 宿主机网络故障
3. DNS 服务器不可达

建议操作：
1. 检查宿主机网络
2. 更换 DNS 服务器（1.1.1.1 或 8.8.8.8）
3. 重启容器网络环境"""
                    send_alert(msg)
                    health['continuous_failures'] = 0
                    save_health(health)
                    time.sleep(60)  # 延长等待时间
                    continue
            
            # 2. DNS 正常，检查代理连接
            ok = check_binance_via_proxy()
            
            if ok:
                if health['continuous_failures'] > 0:
                    log(f"✅ 代理恢复（之前连续失败{health['continuous_failures']}次）")
                else:
                    log("💓 代理正常")
                health['continuous_failures'] = 0
                health['last_ok'] = datetime.now().isoformat()
            else:
                health['continuous_failures'] += 1
                health['total_failures'] += 1
                log(f"⚠️ 代理失败（连续{health['continuous_failures']}次）")
                
                if health['continuous_failures'] >= CONTINUOUS_FAIL_THRESHOLD:
                    msg = f"""代理连续失败{health['continuous_failures']}次！

可能原因：
1. Hysteria 进程挂掉
2. 节点被封/过期
3. 网络问题

建议操作：
1. 检查 hysteria.yaml 配置
2. 重启 Hysteria 服务
3. 切换备用节点"""
                    send_alert(msg)
                    log("🚨 已发送告警！")
                    # 重置计数器，避免重复告警
                    health['continuous_failures'] = 0
            
            save_health(health)
            
        except Exception as e:
            log(f"❌ 检查异常：{e}")
        
        time.sleep(30)

if __name__ == "__main__":
    main()
