#!/usr/bin/env python3
"""
crypto_signal_monitor.py
加密货币自动交易策略 v6.0
优化：WebSocket实时价格 + 分层扫描 + 市场状态识别 + 双TP出场 + 熔断保护
"""

import asyncio
import json
import time
import logging
import os
import sys
import requests
import numpy as np
from datetime import datetime, timedelta
from collections import deque
from typing import Optional

try:
    import aiohttp
    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False
    print("⚠️ aiohttp 未安装，运行 pip install aiohttp")

# ─────────────────────────────────────────────
# 日志（定义在导入前，避免 NameError）
# ─────────────────────────────────────────────
LOG_FILE = "/root/.openclaw/workspace/crypto_monitor.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        # logging.StreamHandler(),  # 禁用控制台输出，防止重复
    ],
)
log = logging.getLogger(__name__)

# 添加脚本目录到路径，以便导入 binance_auto_trade
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 自动交易模块导入
try:
    from binance_auto_trade import place_order, get_all_positions
    AUTO_TRADE_ENABLED = True
    log.info("✅ 自动交易模块已加载")
except Exception as e:
    AUTO_TRADE_ENABLED = False
    log.warning(f"⚠️ 自动交易模块未加载：{e}")

# ─────────────────────────────────────────────
# 配置区
# ─────────────────────────────────────────────
CONFIG = {
    # 交易标的
    "symbols": ["BTC", "ETH", "SOL", "BNB", "DOT", "LINK"],  # 2026-03-28 老公指示：添加 BTC

    # 资金管理
    "total_capital": 100,          # USDT（模拟盘）
    "position_size_pct": 0.10,     # 单仓 10% - 2026-03-28 老公指示
    "max_positions": 4,

    # 开仓阈值（按市场状态分层）- 2026-03-26 老公指示：提高门槛
    "score_threshold": {
        "trending":  70,
        "ranging":   80,
        "volatile":  90,
    },

    # 基础止盈止损（ATR动态覆盖）
    "base_tp_pct":  0.08,
    "base_sl_pct":  0.05,

    # 双TP配置
    "tp1_atr_mult": 3.0,  # 2026-03-25 老公指示：ATR×3.0，平 50% 仓
    "tp2_atr_mult": 6.0,  # 2026-03-25 老公指示：ATR×6.0，平剩余

    # 移动止盈
    "trailing_trigger_pct": 0.02,  # 盈利 2% 启动 - 2026-03-28 老公指示
    "trailing_gap_pct":     0.01,  # 回撤 1% 出场 - 2026-03-28 老公指示

    # ATR止损倍数分层
    "atr_sl_tiers": [
        (0.02, 1.0),   # ATR% < 2%  →  止损1.0倍ATR
        (0.04, 1.5),   # ATR% < 4%  →  止损1.5倍ATR
        (9999, 2.0),   # ATR% >= 4% →  止损2.0倍ATR
    ],

    # 熔断
    "circuit_breaker_pct": -0.10,   # 日亏损超10%触发
    "circuit_breaker_hours": 4,     # 暂停4小时

    # 信号冷却
    "signal_cooldown": {
        "same_direction": 300,    # 同向5分钟
        "opposite":       0,      # 反向立即
    },

    # AI调用限流
    "ai_max_per_hour": 10,
    "ai_min_interval": 180,       # 两次调用最少间隔3分钟

    # 新闻过滤
    "news_blacklist": [
        "hack", "exploit", "ban", "lawsuit", "regulation",
        "crackdown", "freeze", "arrest", "breach", "exit scam"
    ],
    "news_whitelist": [
        "ETF", "approval", "partnership", "institutional",
        "adoption", "upgrade", "launch"
    ],
    "news_suspend_hours": 2,

    # API配置
    "binance_base":    "https://api.binance.com/api/v3",
    "binance_futures": "https://fapi.binance.com/fapi/v1",
    "coingecko_base":  "https://pro-api.coingecko.com/api/v3",
    "coingecko_key":   "CG-DZoCE8UMF3FWpeYhBMvqGq4g",
    "proxy":           "http://127.0.0.1:7890",

    # Qwen AI - 2026-03-24 老公指示：改成和聊天同一个 API
    "qwen_url":  "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
    "qwen_key":  "sk-sp-ae2a006db7b040919e022851a261e0f1",
    "qwen_model": "qwen-plus",

    # 文件路径
    "positions_file":     "crypto_positions.json",
    "state_file":         "crypto_state.json",
    "llm_usage_file":     "llm_usage.json",
    "position_highs_file":"position_highs.json",
    "log_file":           "/root/.openclaw/workspace/crypto_monitor.log",
    "alert_file":         "crypto_alert.txt",

    # 扫描
    "scan_interval": 15,
    
    # 币种精度映射（仅保留当前交易的 5 个币种）
    # 更新：2026-03-19 10:36 清理不交易的币种
    "quantity_precision": {
        'BTC': 3,      # stepSize: 0.001
        'ETH': 3,      # stepSize: 0.001
        'SOL': 2,      # stepSize: 0.01
        'BNB': 3,      # stepSize: 0.001
        'DOT': 1,      # stepSize: 0.1  # 2026-03-25 老公指示：XRP→DOT
        'LINK': 2,     # stepSize: 0.01
    },
    
    # 飞书推送配置
    "feishu_app_id": "cli_a92eff25e5789cbd",
    "feishu_app_secret": "cRcwedFpvtCzOxcQmNktJc2bivnAS4zs",
    "feishu_chat_id": "oc_37fa1adc4c8987639b46fdffb9ce4ed8",
    "feishu_token_cache": "feishu_token.json",
}



# ═══════════════════════════════════════════════════════════════
# 一、WebSocket 实时价格流
# ═══════════════════════════════════════════════════════════════
class PriceStream:
    """
    Binance WebSocket 合并流，所有币种一个连接。
    每次收到推送立刻更新缓存，主循环直接读缓存，0 REST请求。
    """

    def __init__(self, symbols: list[str], proxy: str = None):
        self.symbols = symbols
        streams = "/".join([f"{s.lower()}usdt@ticker" for s in symbols])
        self.url = f"wss://stream.binance.com:9443/stream?streams={streams}"
        self.proxy = proxy
        self.prices: dict = {}
        self._running = False

    async def start(self):
        self._running = True
        while self._running:
            try:
                # 使用 aiohttp 支持代理
                connector = aiohttp.TCPConnector(ssl=False) if self.proxy else None
                async with aiohttp.ClientSession(connector=connector) as session:
                    async with session.ws_connect(
                        self.url,
                        proxy=self.proxy,
                        heartbeat=20,  # aiohttp 使用 heartbeat 代替 ping_interval
                    ) as ws:
                        log.info("WebSocket 价格流已连接 (aiohttp + 代理)")
                        async for msg in ws:
                            if msg.type == aiohttp.WSMsgType.TEXT:
                                data = json.loads(msg.data)
                                t = data.get("data", {})
                                sym = t.get("s", "").replace("USDT", "")
                                if sym in self.symbols:
                                    self.prices[sym] = {
                                        "price":      float(t["c"]),
                                        "high_24h":   float(t["h"]),
                                        "low_24h":    float(t["l"]),
                                        "volume":     float(t["v"]),
                                        "change_24h": float(t["P"]),
                                        "ts":         time.time(),
                                    }
                            elif msg.type == aiohttp.WSMsgType.ERROR:
                                log.warning(f"WebSocket 错误：{ws.exception()}")
                                break
            except Exception as e:
                log.warning(f"WebSocket 断线，5 秒后重连：{e}")
                await asyncio.sleep(5)
    def get(self, symbol: str) -> dict:
        return self.prices.get(symbol, {})

    def is_ready(self) -> bool:
        return len(self.prices) == len(self.symbols)


# ═══════════════════════════════════════════════════════════════
# 二、技术指标计算
# ═══════════════════════════════════════════════════════════════
class IndicatorEngine:
    """
    从 Binance REST 拉K线，计算 RSI / EMA / ATR / 支撑阻力。
    结果缓存60秒，主循环复用。
    """

    def __init__(self):
        self.cache: dict = {}
        self.cache_ts: dict = {}
        self.session = requests.Session()
        self.session.proxies = {"https": CONFIG["proxy"], "http": CONFIG["proxy"]}

    def _get_klines(self, symbol: str, interval: str = "15m", limit: int = 100) -> list:
        try:
            r = self.session.get(
                f"{CONFIG['binance_base']}/klines",
                params={"symbol": f"{symbol}USDT", "interval": interval, "limit": limit},
                timeout=8,
            )
            return r.json()
        except Exception as e:
            log.error(f"K线获取失败 {symbol}: {e}")
            return []

    @staticmethod
    def _ema(values: list[float], period: int) -> float:
        if len(values) < period:
            return values[-1] if values else 0
        k = 2 / (period + 1)
        ema = values[0]
        for v in values[1:]:
            ema = v * k + ema * (1 - k)
        return ema

    @staticmethod
    def _rsi(closes: list[float], period: int = 14) -> float:
        if len(closes) < period + 1:
            return 50.0
        deltas = np.diff(closes)
        gains = np.where(deltas > 0, deltas, 0)
        losses = np.where(deltas < 0, -deltas, 0)
        avg_gain = np.mean(gains[-period:])
        avg_loss = np.mean(losses[-period:])
        if avg_loss == 0:
            return 100.0
        rs = avg_gain / avg_loss
        return 100 - (100 / (1 + rs))

    @staticmethod
    def _atr(klines: list, period: int = 14) -> float:
        if len(klines) < period + 1:
            return 0.0
        trs = []
        for i in range(1, len(klines)):
            h = float(klines[i][2])
            l = float(klines[i][3])
            pc = float(klines[i - 1][4])
            trs.append(max(h - l, abs(h - pc), abs(l - pc)))
        return float(np.mean(trs[-period:]))

    def calc(self, symbol: str) -> dict:
        now = time.time()
        if symbol in self.cache and now - self.cache_ts.get(symbol, 0) < 60:
            return self.cache[symbol]

        klines_15m = self._get_klines(symbol, "15m", 100)
        klines_1h  = self._get_klines(symbol, "1h",  60)

        if not klines_15m:
            return {}

        closes_15m = [float(k[4]) for k in klines_15m]
        closes_1h  = [float(k[4]) for k in klines_1h] if klines_1h else closes_15m
        highs  = [float(k[2]) for k in klines_15m]
        lows   = [float(k[3]) for k in klines_15m]
        vols   = [float(k[5]) for k in klines_15m]

        atr = self._atr(klines_15m)
        price = closes_15m[-1]

        result = {
            # RSI
            "rsi":         self._rsi(closes_15m),
            # EMA 15分钟
            "ema20_15m":   self._ema(closes_15m, 20),
            "ema60_15m":   self._ema(closes_15m, 60),
            # EMA 1小时（多时间框架确认）
            "ema20_1h":    self._ema(closes_1h, 20),
            "ema60_1h":    self._ema(closes_1h, 60),
            # 成交量
            "vol_current": vols[-1],
            "vol_avg20":   float(np.mean(vols[-20:])),
            # ATR
            "atr":         atr,
            "atr_pct":     atr / price if price else 0,
            # 支撑阻力（20根K线）
            "resistance":  max(highs[-20:]),
            "support":     min(lows[-20:]),
            # 市场状态原始数据
            "ema_slope":   (closes_15m[-1] - closes_15m[-5]) / closes_15m[-5] if closes_15m[-5] else 0,
        }

        self.cache[symbol] = result
        self.cache_ts[symbol] = now
        return result


# ═══════════════════════════════════════════════════════════════
# 三、市场状态识别（Regime Detection）
# ═══════════════════════════════════════════════════════════════
def detect_regime(ind: dict) -> str:
    """
    trending  趋势市 → 动量策略，门槛45
    ranging   震荡市 → 反转策略，门槛55
    volatile  高波动 → 保守策略，门槛62 + 减仓
    """
    atr_pct   = ind.get("atr_pct", 0)
    ema_slope = abs(ind.get("ema_slope", 0))

    if atr_pct > 0.05:          # ATR>5% 才是 volatile
        return "volatile"
    elif ema_slope > 0.005:     # EMA 斜率>0.5% 才是 trending（提高门槛）
        return "trending"
    else:
        return "ranging"


# ═══════════════════════════════════════════════════════════════
# 四、情绪数据（恐惧贪婪 + 资金费率）
# ═══════════════════════════════════════════════════════════════
class SentimentEngine:

    def __init__(self):
        self._fg_cache: Optional[int] = None
        self._fr_cache: dict = {}
        self._fg_ts = 0
        self._fr_ts = 0
        self.session = requests.Session()
        self.session.proxies = {"https": CONFIG["proxy"], "http": CONFIG["proxy"]}

    def fear_greed(self) -> int:
        """Alternative.me 恐惧贪婪指数，0-100"""
        if time.time() - self._fg_ts < 300 and self._fg_cache is not None:
            return self._fg_cache
        try:
            r = requests.get("https://api.alternative.me/fng/?limit=1", timeout=8)
            val = int(r.json()["data"][0]["value"])
            self._fg_cache = val
            self._fg_ts = time.time()
            return val
        except Exception as e:
            log.warning(f"恐惧贪婪指数获取失败: {e}")
            return 50  # 中性

    def funding_rates(self, symbols: list[str]) -> dict:
        """Binance资金费率（正=多头付费，偏多情绪）"""
        if time.time() - self._fr_ts < 300:
            return self._fr_cache
        rates = {}
        for sym in symbols:
            try:
                r = self.session.get(
                    f"{CONFIG['binance_futures']}/fundingRate",
                    params={"symbol": f"{sym}USDT", "limit": 1},
                    timeout=8,
                )
                data = r.json()
                if isinstance(data, list) and data:
                    rates[sym] = float(data[0]["fundingRate"])
            except Exception as e:
                log.warning(f"资金费率获取失败 {sym}: {e}")
                rates[sym] = 0.0
        self._fr_cache = rates
        self._fr_ts = time.time()
        return rates

    def sentiment_score(self, symbol: str, direction: str, fg: int, fr: float) -> int:
        """情绪加分，最多+15分"""
        bonus = 0
        if direction == "LONG":
            if fg < 25:       bonus += 10   # 极度恐惧做多
            elif fg < 40:     bonus += 5
            if fr < -0.001:   bonus += 5    # 空头付费，多头有利
        elif direction == "SHORT":
            if fg > 75:       bonus += 10   # 极度贪婪做空
            elif fg > 60:     bonus += 5
            if fr > 0.002:    bonus += 5    # 多头付费过高，反转信号
        return bonus


# ═══════════════════════════════════════════════════════════════
# 五、信号评分系统 v6.0
# ═══════════════════════════════════════════════════════════════
def calc_score(
    symbol: str,
    price_data: dict,
    ind: dict,
    regime: str,
    fg: int,
    funding_rate: float,
    btc_ind: dict,  # 2026-03-28 老公指示：用 BTC 作为大盘参考
) -> tuple[int, str]:
    """
    返回 (score, direction)
    direction: 'LONG' | 'SHORT' | 'NONE'
    """
    if not ind or not price_data:
        return 0, "NONE"

    price      = price_data["price"]
    vol        = price_data["volume"]
    vol_avg    = ind["vol_avg20"]
    atr_pct    = ind["atr_pct"]
    resistance = ind["resistance"]
    support    = ind["support"]

    long_score  = 0
    short_score = 0

    # ① 价格突破（40 分）
    if price >= resistance * 0.999:
        long_score += 40
    if price <= support * 1.001:
        short_score += 40

    # ② 成交量放大确认（30 分）
    if vol > vol_avg * 1.5:
        long_score  += 30
        short_score += 30
    elif vol > vol_avg * 1.2:
        long_score  += 15
        short_score += 15

    # ③ ATR 波动率适中（20 分）
    if 0.005 < atr_pct < 0.03:
        long_score  += 20
        short_score += 20

    # ④ BTC 大盘方向（10 分）- 2026-03-28 老公指示：用 BTC 代替 ETH
    btc_ind = ind.get("btc_ind", {})
    if btc_ind:
        btc_bull = btc_ind.get("ema20_15m", 0) > btc_ind.get("ema60_15m", 0)
        if btc_bull:
            long_score  += 10
            short_score -= 5
        else:
            short_score += 10
            long_score  -= 5

    long_score  = max(0, long_score)
    short_score = max(0, short_score)

    threshold = CONFIG["score_threshold"][regime]
    if long_score > short_score and long_score >= threshold:
        return long_score, "LONG"
    elif short_score > long_score and short_score >= threshold:
        return short_score, "SHORT"

    return max(long_score, short_score), "NONE"


def calc_tp_sl(
    entry: float,
    direction: str,
    ind: dict,
    price_data: dict,
) -> dict:
    """
    返回 {tp1, tp2, sl, tp1_hit, size_remaining}
    
    2026-03-28 老公指示：改用固定百分比止盈止损
    - 止盈：+4%
    - 止损：-2%
    - 暂时替代 ATR 计算
    """
    # 2026-03-28 老公指示：固定百分比止盈止损
    TAKE_PROFIT_PCT = 0.04  # +4%
    STOP_LOSS_PCT   = 0.02  # -2%
    
    if direction == "LONG":
        tp1 = entry * (1 + TAKE_PROFIT_PCT)  # 做多 +4%
        tp2 = entry * (1 + TAKE_PROFIT_PCT * 1.5)  # TP2 = +6%
        sl  = entry * (1 - STOP_LOSS_PCT)    # 做多 -2%
    else:
        tp1 = entry * (1 - TAKE_PROFIT_PCT)  # 做空 -4%
        tp2 = entry * (1 - TAKE_PROFIT_PCT * 1.5)  # TP2 = -6%
        sl  = entry * (1 + STOP_LOSS_PCT)    # 做空 +2%

    return {
        "tp1_price":      round(tp1, 4),
        "tp2_price":      round(tp2, 4),
        "sl_price":       round(sl, 4),
        "tp1_hit":        False,
        "size_remaining": 1.0,
        "peak_pnl":       0.0,   # 移动止盈用
    }


# ═══════════════════════════════════════════════════════════════
# 七、止盈止损检查（15秒必跑，极轻量）
# ═══════════════════════════════════════════════════════════════
def check_exits_fast(positions: list, prices: dict) -> list[tuple]:
    """
    返回 [(position, reason, close_size_ratio)]
    纯价格比较，无任何计算，<5ms
    """
    exits = []
    for pos in positions:
        sym = pos["symbol"]
        p   = prices.get(sym, {}).get("price")
        if not p:
            continue

        tp1 = pos["tp1_price"]
        tp2 = pos["tp2_price"]
        sl  = pos["sl_price"]
        hit = pos.get("tp1_hit", False)
        typ = pos["type"]

        if typ == "LONG":
            if not hit and p >= tp1:
                exits.append((pos, "TP1", 1.0))  # 2026-03-28 老公指示：全平
            elif hit and p >= tp2:
                exits.append((pos, "TP2", pos.get("size_remaining", 0.5)))
            elif p <= sl:
                exits.append((pos, "SL", pos.get("size_remaining", 1.0)))
        else:  # SHORT
            if not hit and p <= tp1:
                exits.append((pos, "TP1", 1.0))  # 2026-03-28 老公指示：全平
            elif hit and p <= tp2:
                exits.append((pos, "TP2", pos.get("size_remaining", 0.5)))
            elif p >= sl:
                exits.append((pos, "SL", pos.get("size_remaining", 1.0)))

    return exits


def update_trailing_stop(positions: list, prices: dict):
    """
    移动止盈：盈利>4.5%后，止损跟踪最高点-1.5%
    只向有利方向移动
    """
    for pos in positions:
        sym = pos["symbol"]
        p   = prices.get(sym, {}).get("price")
        if not p:
            continue

        entry = pos["entry_price"]
        typ   = pos["type"]

        pnl_pct = (p - entry) / entry if typ == "LONG" else (entry - p) / entry

        # 更新峰值盈亏
        if pnl_pct > pos.get("peak_pnl", 0):
            pos["peak_pnl"] = pnl_pct

        if pos.get("peak_pnl", 0) < CONFIG["trailing_trigger_pct"]:
            continue

        # 移动止损
        gap = CONFIG["trailing_gap_pct"]
        if typ == "LONG":
            new_sl = p * (1 - gap)
            if new_sl > pos["sl_price"]:   # 只上移
                pos["sl_price"] = round(new_sl, 4)
        else:
            new_sl = p * (1 + gap)
            if new_sl < pos["sl_price"]:   # 只下移
                pos["sl_price"] = round(new_sl, 4)


# ═══════════════════════════════════════════════════════════════
# 八、熔断器
# ═══════════════════════════════════════════════════════════════
class CircuitBreaker:

    def __init__(self):
        self.daily_pnl   = 0.0
        self.reset_date  = datetime.now().date()
        self.paused_until: Optional[datetime] = None

    def record_trade(self, pnl: float):
        today = datetime.now().date()
        if today != self.reset_date:
            self.daily_pnl = 0.0
            self.reset_date = today
            self.consecutive_losses = 0  # 每日重置连亏计数
        self.daily_pnl += pnl

        # 连亏计数
        if pnl < 0:
            self.consecutive_losses = getattr(self, 'consecutive_losses', 0) + 1
            if self.consecutive_losses >= 3:
                self.paused_until = datetime.now() + timedelta(hours=2)
                log.warning(f"⚠️ 连亏{self.consecutive_losses}次，暂停 2 小时")
                self.consecutive_losses = 0
        else:
            self.consecutive_losses = 0  # 盈利重置

    def is_trading_allowed(self) -> tuple[bool, str]:
        # 检查暂停
        if self.paused_until and datetime.now() < self.paused_until:
            remain = int((self.paused_until - datetime.now()).total_seconds() / 60)
            return False, f"熔断中，还需 {remain} 分钟"

        # 检查日亏损
        loss_pct = self.daily_pnl / CONFIG["total_capital"]
        if loss_pct < CONFIG["circuit_breaker_pct"]:
            self.paused_until = datetime.now() + timedelta(hours=CONFIG["circuit_breaker_hours"])
            msg = f"⚠️ 熔断！日亏损 {loss_pct:.1%}，暂停 {CONFIG['circuit_breaker_hours']} 小时"
            log.warning(msg)
            write_alert(msg)
            return False, msg

        return True, "ok"


# ═══════════════════════════════════════════════════════════════
# 九、信号冷却
# ═══════════════════════════════════════════════════════════════
class CooldownManager:

    def __init__(self):
        self._last: dict = {}   # key → timestamp
        self._push_buffer: dict = {}  # symbol → {signals: [], last_time: 0}

    def can_open(self, symbol: str, direction: str) -> bool:
        now = time.time()
        same_key = f"{direction}_{symbol}"
        opp_dir  = "SHORT" if direction == "LONG" else "LONG"
        opp_key  = f"{opp_dir}_{symbol}"

        # 同向冷却
        elapsed = now - self._last.get(same_key, 0)
        if elapsed < CONFIG["signal_cooldown"]["same_direction"]:
            log.info(f"⏳ {symbol} {direction} 冷却中，还需 {int(CONFIG['signal_cooldown']['same_direction']-elapsed)}秒")
            return False

        self._last.pop(opp_key, None)
        return True

    def record(self, symbol: str, direction: str):
        self._last[f"{direction}_{symbol}"] = time.time()

    def add_push_signal(self, symbol: str, signal: dict):
        """添加推送信号到缓冲区"""
        now = time.time()
        if symbol not in self._push_buffer:
            self._push_buffer[symbol] = {'signals': [], 'last_time': now}
        
        self._push_buffer[symbol]['signals'].append(signal)
        self._push_buffer[symbol]['last_time'] = now

    def flush_push_buffer(self) -> list:
        """刷新推送缓冲，合并同一币种的信号"""
        now = time.time()
        merged_signals = []
        
        for symbol, buffer in self._push_buffer.items():
            if not buffer['signals']:
                continue
            
            # 如果距离上次推送超过 5 分钟，立即发送
            if now - buffer['last_time'] > 300:
                # 合并所有信号
                merged = self._merge_signals(symbol, buffer['signals'])
                merged_signals.append(merged)
                buffer['signals'] = []
                buffer['last_time'] = now  # ✅ 修复：重置 last_time，防止循环推送
        
        return merged_signals

    def _merge_signals(self, symbol: str, signals: list) -> dict:
        """合并多个信号为一个"""
        if len(signals) == 1:
            return signals[0]
        
        # 分离开仓和平仓信号
        opens = [s for s in signals if s.get('action') in ['开多', '开空']]
        closes = [s for s in signals if s.get('action') in ['止盈', '止损', '平仓']]
        
        # 优先显示开仓，其次平仓
        if opens:
            latest_open = opens[-1]
            total_pnl = sum(s.get('pnl', 0) for s in closes)
            if total_pnl != 0:
                latest_open['merged_pnl'] = total_pnl
                latest_open['merged_close_count'] = len(closes)
            return latest_open
        elif closes:
            # 合并所有平仓
            total_pnl = sum(s.get('pnl', 0) for s in closes)
            latest_close = closes[-1].copy()
            latest_close['pnl'] = total_pnl
            latest_close['merged_count'] = len(closes)
            return latest_close
        
        return signals[-1]


# ═══════════════════════════════════════════════════════════════
# 十、AI 预测（限流保护）
# ═══════════════════════════════════════════════════════════════
class AIPredictor:

    def __init__(self):
        self.call_times: deque = deque()
        self.last_call = 0

    def _can_call(self) -> tuple[bool, str]:
        now = time.time()
        self.call_times = deque(t for t in self.call_times if now - t < 3600)
        if len(self.call_times) >= CONFIG["ai_max_per_hour"]:
            return False, "每小时AI调用已满"
        if now - self.last_call < CONFIG["ai_min_interval"]:
            remain = int(CONFIG["ai_min_interval"] - (now - self.last_call))
            return False, f"AI冷却中({remain}s)"
        return True, "ok"

    def predict(self, symbol: str, direction: str, ind: dict, price_data: dict) -> Optional[dict]:
        ok, reason = self._can_call()
        if not ok:
            log.info(f"AI跳过({reason})，使用纯数学决策")
            return None

        prompt = f"""你是加密货币量化交易专家，请基于以下数据给出交易建议。

币种: {symbol}USDT
当前价格: {price_data.get('price', 'N/A')}
RSI(14): {ind.get('rsi', 'N/A'):.1f}
EMA20(15m): {ind.get('ema20_15m', 'N/A'):.2f}
EMA60(15m): {ind.get('ema60_15m', 'N/A'):.2f}
EMA20(1h): {ind.get('ema20_1h', 'N/A'):.2f}
EMA60(1h): {ind.get('ema60_1h', 'N/A'):.2f}
ATR: {ind.get('atr', 'N/A'):.4f}
24h涨跌: {price_data.get('change_24h', 'N/A'):.2f}%
成交量/均量比: {price_data.get('volume', 0) / max(ind.get('vol_avg20', 1), 1):.2f}
数学信号: {direction}

注意：N/A表示数据暂缺，请降低该维度权重。

只返回JSON，不要任何解释：
{{"direction":"做多/做空/震荡","target_price":0.0,"confidence":0,"reasoning":"一句话"}}"""

        try:
            r = requests.post(
                CONFIG["qwen_url"],
                headers={
                    "Authorization": f"Bearer {CONFIG['qwen_key']}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": CONFIG["qwen_model"],
                    "input": {
                        "messages": [
                            {"role": "system", "content": "你是加密货币量化交易专家。"},
                            {"role": "user", "content": prompt}
                        ]
                    },
                    "parameters": {
                        "max_tokens": 200,
                        "temperature": 0.3,
                },
                },
                timeout=15,
                proxies=None,  # 阿里云直连，不走代理
            )
            resp = r.json()
            
            if not resp:
                log.error("AI 响应为空")
                return None
            
            if "output" in resp and "text" in resp["output"]:
                content = resp["output"]["text"]
            elif "choices" in resp and len(resp["choices"]) > 0:
                content = resp["choices"][0].get("message", {}).get("content", "")
            else:
                log.error(f"AI 响应格式未知：{resp}")
                return None
            # 去除可能的markdown fence
            content = content.replace("```json", "").replace("```", "").strip()
            result = json.loads(content)
            self.call_times.append(time.time())
            self.last_call = time.time()
            self._save_usage()
            log.info("AI 预测成功")
            return result
        except Exception as e:
            log.error(f"AI预测失败: {e}")
            return None

    def _save_usage(self):
        try:
            data = {"calls_this_hour": len(self.call_times), "last_call": self.last_call}
            with open(CONFIG["llm_usage_file"], "w") as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════
# 十一、持仓管理
# ═══════════════════════════════════════════════════════════════
def load_positions() -> list:
    """加载持仓并补全缺失字段（兼容旧版本）"""
    try:
        with open(CONFIG["positions_file"]) as f:
            positions = json.load(f)
        
        # 补全缺失字段（兼容旧版本持仓文件）
        for pos in positions:
            if "peak_pnl" not in pos:
                pos["peak_pnl"] = 0.0
            if "high_24h" not in pos:
                pos["high_24h"] = 0.0
            if "low_24h" not in pos:
                pos["low_24h"] = 0.0
            if "tp1_hit" not in pos:
                pos["tp1_hit"] = False
            if "size_remaining" not in pos:
                pos["size_remaining"] = 1.0
        
        return positions
    except Exception as e:
        log.warning(f"⚠️ 加载持仓失败：{e}")
        return []


def save_positions(positions: list):
    with open(CONFIG["positions_file"], "w") as f:
        json.dump(positions, f, indent=2, ensure_ascii=False)


def get_quantity_precision(symbol: str, price: float) -> int:
    """获取币种数量精度"""
    return CONFIG["quantity_precision"].get(symbol.upper(), 8)

def format_quantity(symbol: str, quantity: float, price: float) -> float:
    """格式化数量到正确的精度"""
    precision = get_quantity_precision(symbol, price)
    return round(quantity, precision)

def open_position(
    symbol: str,
    direction: str,
    entry_price: float,
    score: int,
    tp_sl: dict,
    regime: str,
    ai_result: Optional[dict] = None,
) -> dict:
    # 高波动时减仓
    size_pct = CONFIG["position_size_pct"]
    if regime == "volatile":
        size_pct *= 0.6

    # 计算数量并格式化到正确精度
    raw_qty = (CONFIG["total_capital"] * size_pct * 10) / entry_price  # 2026-03-28 老公指示：加 10x 杠杆
    qty = format_quantity(symbol, raw_qty, entry_price)

    # 实盘交易调用
    order_result = None
    if AUTO_TRADE_ENABLED:
        try:
            # 调用 binance_auto_trade 模块下单
            side = "BUY" if direction == "LONG" else "SELL"
            order_result = place_order(
                symbol=f"{symbol}USDT",
                side=side,
                quantity=round(qty, 6),
                leverage=10,  # 2026-03-27 老公指示：3x→10x 测试两天
                tp_price=tp_sl.get("tp1_price"),
                sl_price=tp_sl.get("sl_price"),
                price=entry_price,
                reduce_only=False,
            )
            log.info(f"📝 下单结果：{order_result}")
        except Exception as e:
            log.error(f"❌ 下单失败：{e}")
            order_result = {"error": str(e)}

    pos = {
        "symbol":       symbol,
        "type":         direction,
        "entry_price":  entry_price,
        "entry_time":   datetime.now().isoformat(),
        "qty":          round(qty, 6),
        "score":        score,
        "regime":       regime,
        "ai_result":    ai_result,
        "order_result": order_result,
        "high_24h":     0.0,
        "low_24h":      0.0,
        **tp_sl,
    }

    # 检查订单是否真正成功
    order_success = True
    if order_result:
        order_success = order_result.get('success', True)
    
    msg = (
        f"🟢 开多 {symbol}" if direction == "LONG" else f"🔴 开空 {symbol}"
    ) + f" @{entry_price} | 评分:{score} | 状态:{regime}"
    if ai_result:
        msg += f" | AI:{ai_result.get('direction')}({ai_result.get('confidence')}%)"
    if not order_success:
        msg += f" | ❌ 下单失败"
    else:
        msg += f" | ✅ 下单成功"
    log.info(msg)
    write_alert(msg)
    
    # 只有订单成功才推送飞书（走缓冲区合并，避免刷屏）
    if order_success:
        push_signal_alert({
            'symbol': symbol,
            'type': direction,
            'action': '开多' if direction == 'LONG' else '开空',
            'price': entry_price,
            'score': score,
            'regime': regime,
            'tp_price': pos.get('tp_price', 0),
            'sl_price': pos.get('sl_price', 0),
        }, immediate=False)  # 改为缓冲模式
    
    return pos


def close_position(pos: dict, reason: str, size_ratio: float, current_price: float):
    entry = pos["entry_price"]
    typ   = pos["type"]
    symbol = pos["symbol"]
    qty_raw = pos.get("qty", 0) * size_ratio
    
    # ✅ 修复：使用 format_quantity 格式化到正确精度
    from binance_auto_trade import format_quantity
    qty = format_quantity(symbol, qty_raw, entry)

    # 实盘平仓调用（使用 place_order with reduce_only=True）
    # 平仓重试机制（最多 3 次）
    close_result = None
    if AUTO_TRADE_ENABLED and size_ratio > 0:
        for attempt in range(3):
            try:
                side = "SELL" if typ == "LONG" else "BUY"
                close_result = place_order(
                    symbol=f"{symbol}USDT",
                    side=side,
                    quantity=qty,
                    leverage=10,  # 2026-03-27 老公指示：3x→10x 测试两天
                    reduce_only=True,
                )
                log.info(f"📝 平仓结果：{close_result}")
                # 成功就跳出重试
                if close_result.get('success', True):
                    break
                else:
                    log.warning(f"⚠️ 平仓第{attempt+1}次失败，{'重试' if attempt < 2 else '放弃'}")
                    if attempt < 2:
                        time.sleep(2)
            except Exception as e:
                log.error(f"❌ 平仓异常第{attempt+1}次：{e}")
                close_result = {"error": str(e), "success": False}
                if attempt < 2:
                    time.sleep(2)

    # 计算盈亏
    pnl_pct = (current_price - entry) / entry if typ == "LONG" else (entry - current_price) / entry
    pnl_usdt = CONFIG["total_capital"] * CONFIG["position_size_pct"] * pnl_pct * size_ratio
    # 2026-03-25 老公指示：用实际成交价计算真实盈亏
    if close_result and close_result.get('success') and close_result.get('order'):
        realized = close_result.get('order', {}).get('realizedPnl')
        if realized is not None:
            pnl_usdt = float(realized)


    # 检查平仓是否真正成功
    close_success = True
    if close_result:
        close_success = close_result.get('success', True)
    
    emoji = "✅" if pnl_usdt >= 0 else "❌"
    msg = (
        f"{emoji} 平仓 {symbol} {reason} | "
        f"入场:{entry:.4f} 出场:{current_price:.4f} | "
        f"PnL:{pnl_pct*100:.2f}% ({pnl_usdt:+.2f}USDT) | "
        f"平{size_ratio*100:.0f}%仓"
    )
    if not close_success:
        msg += f" | ❌ 平仓失败"
    else:
        msg += f" | ✅ 平仓成功"
    log.info(msg)
    write_alert(msg)
    
    # 只有平仓成功才推送飞书（走缓冲区合并，避免刷屏）
    if close_success:
        # 确保 score 和 regime 有值（从持仓中读取，如果没有则用 0/unknown）
        score = pos.get('score')
        if score is None or score == '':
            score = 0
        regime = pos.get('regime')
        if regime is None or regime == '':
            regime = 'unknown'
        
        push_signal_alert({
            'symbol': symbol,
            'type': typ,
            'action': '止盈' if 'TP' in reason else '止损',
            'price': current_price,
            'score': score,
            'regime': regime,
            'pnl': pnl_usdt,
        }, immediate=False)  # 改为缓冲模式
    
    return pnl_usdt


# ═══════════════════════════════════════════════════════════════
# 十二、新闻过滤
# ═══════════════════════════════════════════════════════════════
class NewsFilter:

    def __init__(self):
        self.suspended: dict = {}   # symbol → 解封时间
        self.major_news_cache: dict = {}  # symbol → (has_major, timestamp)

    def check_suspend(self, symbol: str) -> bool:
        """True=允许交易"""
        if symbol in self.suspended:
            if datetime.now() < self.suspended[symbol]:
                return False
            del self.suspended[symbol]
        return True

    def process_news(self, title: str, symbols: list[str]):
        title_lower = title.lower()
        is_negative = any(kw in title_lower for kw in CONFIG["news_blacklist"])
        is_positive = any(kw in title_lower for kw in CONFIG["news_whitelist"])

        if is_negative:
            until = datetime.now() + timedelta(hours=CONFIG["news_suspend_hours"])
            for sym in symbols:
                if any(sym.lower() in title_lower for sym in symbols):
                    self.suspended[sym] = until
                    log.warning(f"📰 负面新闻，暂停 {sym} {CONFIG['news_suspend_hours']}h: {title}")
        elif is_positive:
            log.info(f"📰 利好新闻：{title}")

    def has_major_news(self, symbol: str) -> bool:
        """检查是否有重大新闻（简化版：暂时返回 False，等待新闻模块集成）"""
        # TODO: 集成新闻抓取模块后，检查是否有美联储、SEC、利率等重大新闻
        # 目前返回 False，不影响交易逻辑
        return False


# ═══════════════════════════════════════════════════════════════
# 十三、飞书推送
# ═══════════════════════════════════════════════════════════════
def get_feishu_token(force_refresh: bool = False) -> Optional[str]:
    """获取飞书 tenant_access_token（带缓存）"""
    cache_file = CONFIG["feishu_token_cache"]
    now = time.time()
    
    # 强制刷新时跳过缓存
    if force_refresh and os.path.exists(cache_file):
        try:
            os.remove(cache_file)
            log.info("🔄 强制刷新飞书 token")
        except Exception as e:
            log.warning(f"删除旧 token 失败：{e}")
    
    # 尝试读取缓存
    try:
        if os.path.exists(cache_file):
            with open(cache_file) as f:
                cache = json.load(f)
            if now - cache.get('time', 0) < 7000:  # token 有效期 2 小时，7000 秒安全边际
                return cache.get('token')
    except Exception as e:
        log.warning(f"读取飞书 token 缓存失败：{e}")
    
    # 获取新 token
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    payload = {
        "app_id": CONFIG["feishu_app_id"],
        "app_secret": CONFIG["feishu_app_secret"]
    }
    try:
        # 飞书 API 不能走代理，必须直连
        r = requests.post(url, json=payload, timeout=10, proxies=None)
        data = r.json()
        if data.get('code') == 0:
            token = data.get('tenant_access_token')
            # 缓存 token
            with open(cache_file, 'w') as f:
                json.dump({'token': token, 'time': now}, f)
            log.info("✅ 飞书 token 已更新")
            return token
        else:
            log.error(f"❌ 获取飞书 token 失败：{data}")
    except Exception as e:
        log.error(f"❌ 获取飞书 token 异常：{e}")
    return None


def push_feishu_card(title: str, elements: list, template: str = "blue"):
    """推送飞书卡片消息"""
    token = get_feishu_token()
    if not token:
        log.warning("⚠️ 飞书 token 缺失，跳过推送")
        return False
    
    # 构建卡片内容（飞书格式）
    card_content = {
        "config": {"wide_screen_mode": True},
        "header": {
            "template": template,
            "title": {"tag": "plain_text", "content": title}
        },
        "elements": elements
    }
    
    # 发送消息
    url = "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    # 注意：content 字段必须是 JSON 字符串，不能用 json=payload（会双重序列化）
    payload = {
        "receive_id": CONFIG["feishu_chat_id"],
        "msg_type": "interactive",
        "content": json.dumps(card_content, ensure_ascii=False)
    }
    
    try:
        # 使用 data 而不是 json，避免 content 字段被二次序列化
        # 飞书 API 不能走代理，必须直连
        r = requests.post(url, headers=headers, data=json.dumps(payload, ensure_ascii=False), timeout=10, proxies=None)
        data = r.json()
        if data.get('code') == 0:
            log.info("✅ 飞书推送成功")
            return True
        else:
            # token 过期时强制刷新并重试
            if data.get('code') == 99991663:
                log.warning("⚠️ 飞书 token 过期，强制刷新后重试...")
                token = get_feishu_token(force_refresh=True)
                if token:
                    headers["Authorization"] = f"Bearer {token}"
                    r = requests.post(url, headers=headers, data=json.dumps(payload, ensure_ascii=False), timeout=10)
                    data = r.json()
                    if data.get('code') == 0:
                        log.info("✅ 飞书推送成功（刷新 token 后）")
                        return True
            log.error(f"❌ 飞书推送失败：{data}")
            return False
    except Exception as e:
        log.error(f"❌ 飞书推送异常：{e}")
        return False


def push_signal_alert(signal: dict, immediate: bool = False):
    """推送交易信号告警（开仓/平仓）- 支持缓冲合并"""
    global cooldown_manager
    symbol = signal['symbol']
    
    # 添加到缓冲区（除非立即推送）
    try:
        if not immediate and cooldown_manager:
            cooldown_manager.add_push_signal(symbol, signal)
            return
    except NameError:
        pass  # cooldown_manager 未初始化，直接推送
    
    # 立即推送
    _send_push_signal(signal)

def _send_push_signal(signal: dict):
    """实际发送推送信号"""
    symbol = signal['symbol']
    sig_type = signal.get('type', 'UNKNOWN')
    action = signal.get('action', '信号')
    price = signal.get('price', 0)
    score = signal.get('score', 0)
    regime = signal.get('regime', 'unknown')
    tp_price = signal.get('tp_price', 0)
    sl_price = signal.get('sl_price', 0)
    pnl = signal.get('pnl', 0)
    merged_pnl = signal.get('merged_pnl', 0)
    merged_count = signal.get('merged_count', 0)
    merged_close_count = signal.get('merged_close_count', 0)
    
    # 颜色和 emoji
    if sig_type == 'LONG':
        emoji = '🟢'
        template = 'green'
        type_text = '开多'
    elif sig_type == 'SHORT':
        emoji = '🔴'
        template = 'red'
        type_text = '开空'
    else:
        emoji = '⚠️'
        template = 'blue'
        type_text = action
    
    # 构建卡片元素（使用 div 标签）
    content = f"**{emoji} 币种：** {symbol}\n"
    content += f"**📊 方向：** {type_text}\n"
    content += f"**💰 价格：** ${price:,.2f}\n"
    content += f"**📈 评分：** {score}/100\n"
    content += f"**🎯 状态：** {regime}\n"
    
    # 开仓信号添加止盈止损
    if action in ['开多', '开空'] and tp_price and sl_price:
        content += f"**🎯 止盈：** ${tp_price:,.2f}\n"
        content += f"**🛑 止损：** ${sl_price:,.2f}\n"
    
    # 平仓信号添加盈亏
    if action in ['止盈', '止损', '平仓']:
        content += f"**💰 盈亏：** {pnl:+.2f} USDT\n"
        if merged_count and merged_count > 1:
            content += f"**📦 合并：** {merged_count} 次平仓\n"
    
    # 如果有合并的平仓盈亏
    if merged_pnl != 0:
        content += f"**💰 累计盈亏：** {merged_pnl:+.2f} USDT\n"
        if merged_close_count:
            content += f"**📦 包含：** {merged_close_count} 次平仓\n"
    
    elements = [
        {
            "tag": "div",
            "text": {
                "tag": "lark_md",
                "content": content
            }
        },
        {
            "tag": "note",
            "elements": [{
                "tag": "plain_text",
                "content": f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} (UTC+8) · ⚠️ 仅供参考，注意风险"
            }]
        }
    ]
    
    title = f"🚨 {action} - {symbol}"
    push_feishu_card(title, elements, template)


def push_hourly_report(positions: list, prices: dict, indicators: dict, daily_pnl: float, fg: int):
    """推送整点汇报（显示所有币种的价格和评分）"""
    from binance_auto_trade import request as api_request
    
    # 恐惧贪婪描述
    if fg < 25:
        fg_text = "极度恐惧"
        fg_color = "🔴"
    elif fg < 40:
        fg_text = "恐惧"
        fg_color = "🟠"
    elif fg < 60:
        fg_text = "中性"
        fg_color = "🟡"
    elif fg < 75:
        fg_text = "贪婪"
        fg_color = "🟢"
    else:
        fg_text = "极度贪婪"
        fg_color = "🔵"
    
    # 构建持仓列表（包含价格、评分、盈亏）
    pos_lines = []
    for pos in positions:
        symbol = pos['symbol']
        pos_type = pos['type']
        entry_price = pos['entry_price']
        
        # ✅ 从 prices 获取实时价格
        current_price = prices.get(symbol, {}).get('price', entry_price)
        
        # ✅ 实时计算评分（和全部币种列表一致）
        ind = indicators.get(symbol, {})
        regime = detect_regime(ind)
        fr = 0
        btc_ind = indicators.get("BTC", {})  # 2026-03-28 老公指示：用 BTC 作为大盘参考
        score, direction = calc_score(symbol, prices.get(symbol, {}), ind, regime, fg, fr, btc_ind)
        
        # 计算盈亏百分比
        if pos_type == 'LONG':
            pnl_pct = ((current_price - entry_price) / entry_price * 100)
        else:
            pnl_pct = ((entry_price - current_price) / entry_price * 100)
        
        pos_lines.append(f"**{symbol}** {pos_type} | 开仓：${entry_price:,.2f} | 当前：${current_price:,.2f} | 评分：{score} | 盈亏：{pnl_pct:+.2f}%")
    
    # 构建所有币种的价格和评分列表
    all_coins_lines = []
    
    # 如果 indicators 为空，实时计算指标
    if not indicators:
        log.warning("⚠️ 整点汇报时 indicators 为空，实时计算指标...")
        indicator_engine = IndicatorEngine()
        for sym in CONFIG["symbols"]:
            ind = indicator_engine.calc(sym)
            if ind:
                indicators[sym] = ind
    
    for symbol in CONFIG["symbols"]:
        if prices.get(symbol):
            price = prices[symbol].get('price', 0)
            change_24h = prices[symbol].get('change_24h', 0)
            
            # 计算评分
            ind = indicators.get(symbol, {})
            regime = detect_regime(ind)
            fr = 0
            btc_ind = indicators.get("BTC", {})
            score, direction = calc_score(symbol, prices[symbol], ind, regime, fg, fr, btc_ind)
            
            # 标记持仓状态
            holding = "📌" if any(p['symbol'] == symbol for p in positions) else "  "
            
            all_coins_lines.append(f"{holding} **{symbol}** ${price:,.2f} ({change_24h:+.2f}%) | 评分：{score} | 信号：{direction}")
    
    # 构建卡片元素（使用 div 标签）
    content_lines = [
        f"**📊 今日盈亏：** {daily_pnl:+.2f} USDT",
        f"**😨 恐惧贪婪：** {fg_color} {fg_text} ({fg})",
        f"**📦 持仓数：** {len(positions)}/{CONFIG['max_positions']}"
    ]
    
    content_lines.append("")
    content_lines.append("**📊 全部币种:**")
    content_lines.extend(all_coins_lines)
    
    if pos_lines:
        content_lines.append("")
        content_lines.append("**📌 持仓详情:**")
        content_lines.extend(pos_lines)
    
    elements = [
        {
            "tag": "div",
            "text": {
                "tag": "lark_md",
                "content": "\n".join(content_lines)
            }
        },
        {
            "tag": "note",
            "elements": [{
                "tag": "plain_text",
                "content": f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} (UTC+8)"
            }]
        }
    ]
    
    title = "📊 整点汇报"
    return push_feishu_card(title, elements, "blue")


# ═══════════════════════════════════════════════════════════════
# 十四、辅助工具
# ═══════════════════════════════════════════════════════════════
def write_alert(msg: str):
    try:
        with open(CONFIG["alert_file"], "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
    except Exception:
        pass


def save_state(state: dict):
    with open(CONFIG["state_file"], "w") as f:
        json.dump(state, f, indent=2, ensure_ascii=False, default=str)


# ═══════════════════════════════════════════════════════════════
# 十四、分层调度器
# ═══════════════════════════════════════════════════════════════
class ScanScheduler:
    """控制各任务执行频率，避免每15秒都跑重计算"""

    def __init__(self):
        self.tick = 0   # 每15秒+1

    def tick_up(self):
        self.tick += 1

    def should(self, task: str) -> bool:
        # task → 每隔多少个tick执行一次
        intervals = {
            "indicators":   4,    # 60秒
            "sentiment":    20,   # 300秒
            "funding":      20,   # 300秒
            "hourly_report":240,  # 3600秒
        }
        n = intervals.get(task, 1)
        return self.tick % n == 0


# ═══════════════════════════════════════════════════════════════
# 十五、整点汇报
# ═══════════════════════════════════════════════════════════════
def hourly_report(positions: list, prices: dict, indicators: dict, circuit: CircuitBreaker, fg: int):
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    
    # 如果数据为空，从 API 重新获取
    if not positions:
        log.warning("⚠️ 小时汇报时 positions 为空，从 API 重新获取...")
        try:
            from binance_auto_trade import get_all_positions
            api_positions = get_all_positions()
            if api_positions:
                positions = []
                for p in api_positions:
                    amt = float(p.get('amount', 0))
                    if amt != 0:
                        symbol = p['symbol']
                        pos = {
                            'symbol': symbol,
                            'type': 'SHORT' if amt < 0 else 'LONG',
                            'entry_price': float(p.get('entry_price', 0)),
                            'entry_time': datetime.now().isoformat(),
                            'qty': abs(amt),
                            'score': 55,
                            'regime': 'trending',
                            'ai_result': None,
                            'order_result': {'success': True, 'message': '从 API 同步'},
                            'high_24h': 0.0,
                            'low_24h': 0.0,
                            'tp1_price': 0.0,
                            'tp2_price': 0.0,
                            'sl_price': 0.0,
                            'tp1_hit': False,
                            'size_remaining': 1.0,
                            'peak_pnl': 0.0
                        }
                        positions.append(pos)
                log.info(f"✅ 小时汇报从 API 恢复 {len(positions)} 个持仓")
        except Exception as e:
            log.error(f"❌ 小时汇报获取持仓失败：{e}")
    
    lines = [
        f"\n{'='*50}",
        f"📊 整点汇报 {now}",
        f"恐惧贪婪指数: {fg} ({'极度恐惧' if fg<25 else '恐惧' if fg<40 else '中性' if fg<60 else '贪婪' if fg<75 else '极度贪婪'})",
        f"今日PnL: {circuit.daily_pnl:+.2f} USDT ({circuit.daily_pnl/CONFIG['total_capital']*100:+.1f}%)",
        f"持仓数: {len(positions)}/{CONFIG['max_positions']}",
    ]
    for pos in positions:
        sym = pos["symbol"]
        p   = prices.get(sym, {}).get("price", 0)
        entry = pos["entry_price"]
        typ = pos["type"]
        pnl_pct = (p - entry) / entry if typ == "LONG" else (entry - p) / entry
        lines.append(
            f"  {'🟢' if typ=='LONG' else '🔴'} {sym} {typ} @{entry:.4f} "
            f"现价:{p:.4f} PnL:{pnl_pct*100:+.2f}%"
        )
    for sym in CONFIG["symbols"]:
        pd = prices.get(sym, {})
        if pd.get('price', 0):  # 只显示有价格的币种
            lines.append(
                f"  {sym}: {pd.get('price',0):.4f} ({pd.get('change_24h',0):+.2f}%)"
            )
    lines.append("=" * 50)
    report = "\n".join(lines)
    log.info(report)
    write_alert(report)
    
    # 📊 添加各币种评分详情日志（2026-03-27 老公指示）
    score_lines = [f"\n📊 评分详情 ({now}):"]
    btc_ind = indicators.get("BTC", {})  # 2026-03-28 老公指示：用 BTC 代替 ETH 作为大盘参考
    for sym in CONFIG["symbols"]:
        pd = prices.get(sym, {})
        ind = indicators.get(sym, {})
        if pd.get('price', 0) and ind:
            regime = detect_regime(ind)
            score, direction = calc_score(sym, pd, ind, regime, fg, 0, btc_ind)
            rsi = ind.get('rsi', 0)
            ma60_ok = "✓" if pd.get('price', 0) >= ind.get('ma60', 999999) else "✗"
            score_lines.append(
                f"  {sym}: {score}分 (RSI:{rsi:.0f}, 24h:{pd.get('change_24h',0):+.1f}%, MA60:{ma60_ok}) → 信号：{direction}"
            )
    score_log = "\n".join(score_lines)
    log.info(score_log)
    
    # 推送飞书（带错误检查和重试）
    try:
        success = push_hourly_report(positions, prices, indicators, circuit.daily_pnl, fg)
        if not success:
            log.warning("⚠️ 小时汇报推送失败，已跳过")
    except Exception as e:
        log.error(f"❌ 小时汇报推送异常：{e}")


# ═══════════════════════════════════════════════════════════════
# 十六、主循环
# ═══════════════════════════════════════════════════════════════
async def main():
    global cooldown_manager
    log.info("🚀 crypto_signal_monitor v6.0 启动")

    # 初始化各模块
    price_stream = PriceStream(CONFIG["symbols"], proxy=CONFIG["proxy"])
    indicator_engine = IndicatorEngine()
    sentiment_engine = SentimentEngine()
    ai_predictor     = AIPredictor()
    circuit_breaker  = CircuitBreaker()
    cooldown_manager = CooldownManager()
    news_filter      = NewsFilter()
    scheduler        = ScanScheduler()

    # 缓存
    indicators:  dict = {}
    fg_cache:    int  = 50
    fr_cache:    dict = {}

    # 启动WebSocket（后台）
    asyncio.create_task(price_stream.start())

    # 等待WebSocket就绪
    log.info("等待WebSocket价格流就绪...")
    for _ in range(30):
        if price_stream.is_ready():
            break
        await asyncio.sleep(1)
    log.info(f"价格流就绪: {list(price_stream.prices.keys())}")

    # 加载持仓（从 Binance API 同步真实持仓）
    log.info("🔄 从 Binance API 同步持仓...")
    try:
        api_positions = get_all_positions()
        # 如果 API 返回空，尝试从本地文件加载
        if not api_positions:
            log.warning("⚠️ Binance API 返回空持仓，尝试从本地文件加载...")
            positions = load_positions()
            if positions:
                log.info(f"✅ 从本地文件恢复 {len(positions)} 个持仓")
            else:
                positions = []
                log.warning("⚠️ 本地文件也无持仓，初始化为空")
        else:
            # 过滤有实际持仓的币种
            positions = []
            for p in api_positions:
                amt = float(p.get('amount', 0))
                if amt != 0:
                    # 转换为本地格式
                    symbol = p['symbol']
                    pos = {
                        'symbol': symbol,
                        'type': 'SHORT' if amt < 0 else 'LONG',
                        'entry_price': float(p.get('entry_price', 0)),
                        'entry_time': datetime.now().isoformat(),
                        'qty': abs(amt),
                        'score': 55,
                        'regime': 'trending',
                        'ai_result': None,
                        'order_result': {'success': True, 'message': '从 API 同步'},
                        'high_24h': 0.0,
                        'low_24h': 0.0,
                        'tp1_price': 0.0,
                        'tp2_price': 0.0,
                        'sl_price': 0.0,
                        'tp1_hit': False,
                        'size_remaining': 1.0,
                        'peak_pnl': 0.0
                    }
                    positions.append(pos)
                    log.info(f"✅ 同步持仓：{symbol} {pos['type']} @ ${pos['entry_price']:.2f}")
        save_positions(positions)
        log.info(f"✅ 持仓同步完成：{len(positions)}个")
    except Exception as e:
        log.error(f"❌ 持仓同步失败：{e}")
        positions = load_positions()  # 回退到本地文件

    # 从状态文件恢复上次推送时间（防止重启后重复推送）
    last_report_hour = -1
    last_report_time = 0
    try:
        if os.path.exists(CONFIG["state_file"]):
            with open(CONFIG["state_file"]) as f:
                state = json.load(f)
                if state.get("last_report_hour"):
                    last_report_hour = state["last_report_hour"]
                if state.get("last_report_time"):
                    last_report_time = state["last_report_time"]
                log.info(f"📋 恢复推送状态：last_report_hour={last_report_hour}, last_report_time={last_report_time}")
    except Exception as e:
        log.warning(f"⚠️ 加载状态文件失败：{e}")

    while True:
        loop_start = time.time()
        scheduler.tick_up()
        
        # 2026-03-28 老公指示：爆仓保护检查（保证金率<5% 强制平仓）
        try:
            from binance_auto_trade import check_margin_ratio_protection
            check_margin_ratio_protection()
        except Exception as e:
            log.warning(f"⚠️ 爆仓保护检查失败：{e}")

        # 每 20 个 tick（5 分钟）从 API 同步持仓
        # 🐛 Bug 修复：API 是真相，本地是缓存。API 返回 0 说明真的没有持仓
        if scheduler.tick % 20 == 0:
            try:
                api_positions = get_all_positions()
                api_count = sum(1 for p in api_positions if float(p.get('amount', 0)) != 0)
                
                # 🐛 关键修复：API 返回 0 时，必须清空本地缓存
                if api_count == 0:
                    if len(positions) > 0:
                        log.info(f"🔄 持仓同步：API 持仓=0，清空本地缓存（原{len(positions)}个）")
                        positions = []
                        save_positions(positions)
                        log.info("✅ 持仓同步完成：0 个（API 为空）")
                elif api_count != len(positions):
                    log.info(f"🔄 持仓同步：本地{len(positions)}个 → API{api_count}个")
                    new_positions = []
                    for p in api_positions:
                        amt = float(p.get('amount', 0))
                        if amt != 0:
                            symbol = p['symbol']
                            entry = float(p.get('entry_price', 0))
                            # 重建止盈止损字段（防止 KeyError）
                            atr = abs(entry * 0.015)  # 估算 ATR
                            tp1 = round(entry * (1 - 0.015) if amt < 0 else entry * (1 + 0.015), 4)
                            tp2 = round(entry * (1 - 0.03) if amt < 0 else entry * (1 + 0.03), 4)
                            sl = round(entry * (1 + 0.008) if amt < 0 else entry * (1 - 0.008), 4)
                            new_positions.append({
                                'symbol': symbol,
                                'type': 'SHORT' if amt < 0 else 'LONG',
                                'entry_price': entry,
                                'qty': abs(amt),
                                'tp1_price': tp1,
                                'tp2_price': tp2,
                                'sl_price': sl,
                                'tp1_hit': False,
                                'size_remaining': 1.0,
                            })
                    positions = new_positions
                    save_positions(positions)
                    log.info(f"✅ 持仓同步完成：{len(positions)}个")
            except Exception as e:
                log.error(f"⚠️ 同步失败：{e}")

        try:
            # ──────────────────────────────────
            # Step 1: 获取实时价格（0 REST请求）
            # ──────────────────────────────────
            prices = {sym: price_stream.get(sym) for sym in CONFIG["symbols"]}

            # ──────────────────────────────────
            # Step 2: 止盈止损检查（每15秒，最轻量）
            # ──────────────────────────────────
            exits = check_exits_fast(positions, prices)
            for pos, reason, size in exits:
                p = prices[pos["symbol"]]["price"]
                pnl = close_position(pos, reason, size, p)
                circuit_breaker.record_trade(pnl)

                if reason == "TP1":
                    # 2026-03-28 老公指示：TP1 全平，直接移除
                    positions.remove(pos)
                    log.info(f"TP1 触发 {pos['symbol']}，全平移除")
                elif reason == "TP2":
                    positions.remove(pos)
                    # 🐛 Bug 修复：TP2 平仓后立即同步 API，防止本地缓存残留
                    if reason == "TP2":
                        try:
                            api_positions = get_all_positions()
                            api_count = sum(1 for p in api_positions if float(p.get('amount', 0)) != 0)
                            if api_count == 0:
                                positions = []
                                save_positions(positions)
                                log.info("📊 TP2 平仓后同步：API 持仓为 0，清空本地缓存")
                            else:
                                log.info(f"📊 TP2 平仓后同步：API 还有{api_count}个持仓，保留本地缓存")
                        except Exception as e:
                            log.error(f"⚠️ TP2 平仓后同步失败：{e}")


            # 移动止盈更新
            update_trailing_stop(positions, prices)
            save_positions(positions)


            # ──────────────────────────────────
            # Step 3: 指标计算（60秒一次）
            # ──────────────────────────────────
            if scheduler.should("indicators"):
                for sym in CONFIG["symbols"]:
                    ind = indicator_engine.calc(sym)
                    if ind:
                        indicators[sym] = ind

            # ──────────────────────────────────
            # Step 4: 情绪数据（300秒一次）
            # ──────────────────────────────────
            if scheduler.should("sentiment"):
                fg_cache = sentiment_engine.fear_greed()
            if scheduler.should("funding"):
                fr_cache = sentiment_engine.funding_rates(CONFIG["symbols"])

            # ──────────────────────────────────
            # Step 5: 开仓评分（60秒一次）
            # ──────────────────────────────────
            if scheduler.should("indicators") and indicators:
                # 熔断检查
                allowed, reason = circuit_breaker.is_trading_allowed()
                if not allowed:
                    log.info(f"交易暂停: {reason}")
                else:
                    btc_ind = indicators.get("BTC", {})  # 2026-03-28 老公指示：用 BTC 作为大盘参考
                    
                    # 🐛 Bug 修复：API 是真相，本地是缓存
                    # 优先相信 API，只有当 API 失败时才用本地缓存
                    current_pos = get_all_positions()
                    api_count = sum(1 for p in current_pos if float(p.get("amount", 0)) != 0)
                    local_count = len(positions)
                    
                    # API 返回 0 时，说明真的没有持仓（刚平仓）
                    # API 有数据时，相信 API
                    # API 失败/异常时，才用本地缓存
                    if api_count > 0:
                        actual_count = api_count  # 相信 API
                    else:
                        actual_count = local_count  # API 为空，用本地（可能是刚启动）
                    
                    log.info(f"📊 开仓前检查：API 持仓={api_count}, 本地缓存={local_count}, 采用={actual_count}/{CONFIG['max_positions']}")
                    
                    # 开仓计数器（本循环内累加）
                    opened_this_loop = 0

                    for sym in CONFIG["symbols"]:
                        # 检查是否已满仓（包含本循环已开的仓位）
                        if actual_count + opened_this_loop >= CONFIG["max_positions"]:
                            log.info(f"⚠️ {sym} 已达最大持仓数，跳过开仓")
                            break
                        if not indicators.get(sym) or not prices.get(sym):
                            continue
                        if not news_filter.check_suspend(sym):
                            continue

                        ind    = indicators[sym]
                        pd     = prices[sym]
                        regime = detect_regime(ind)
                        fr     = fr_cache.get(sym, 0)

                        score, direction = calc_score(
                            sym, pd, ind, regime, fg_cache, fr, btc_ind
                        )

                        if direction == "NONE":
                            continue
                        if not cooldown_manager.can_open(sym, direction):
                            continue

                        # 同一币种不能重复开仓
                        existing_same_symbol = [p for p in positions if p["symbol"] == sym]
                        if existing_same_symbol:
                            log.info(f"⚠️ {sym} 已有持仓，跳过重复开仓")
                            continue

                        # 2026-03-28 老公指示：移除同方向限制，只保留总持仓数限制
                        # 原因：同方向 0-1U 浮动的仓位占位置，导致其他信号进不来

                        # ═══════════════════════════════════════
                        # AI 触发条件判断（v6.1 优化）
                        # ═══════════════════════════════════════
                        # 只有"不确定"场景才调用 AI，不是"确定"场景！
                        should_trigger_ai = False
                        
                        # 获取 24h 涨跌
                        change_24h = pd.get('change_24h', 0)
                        
                        # 1. 重大新闻（通过新闻关键词判断）
                        if news_filter.has_major_news(sym):
                            should_trigger_ai = True
                            log.info(f"🤖 {sym} 触发 AI：重大新闻")
                        
                        # 2. 异常波动 >15%（原 20%，2026-03-16 优化）
                        if abs(change_24h) > 15:
                            should_trigger_ai = True
                            log.info(f"🤖 {sym} 触发 AI：异常波动 {change_24h:+.1f}%")
                        
                        # 3. 临界信号（评分在阈值附近徘徊，数学模型最不确定时）
                        threshold = CONFIG["score_threshold"][regime]
                        if threshold <= score <= threshold + 2:  # 缩窄范围 5→2 分
                            should_trigger_ai = True
                            log.info(f"🤖 {sym} 触发 AI：临界信号 {score}分")
                        
                        # ❌ 随机采样已关闭（2026-03-16 13:19 老公指示）
# DISABLED:                         # 4. 随机采样 0.5%（原 2%，2026-03-16 11:38 优化）- 减少无意义调用
# DISABLED:                         import random
# DISABLED:                         if random.random() < 0.005:
# DISABLED:                             should_trigger_ai = True
# DISABLED:                             log.info(f"🤖 {sym} 触发 AI：随机采样")
                        
                        # ❌ 已删除：有效信号≥55 分（高分信号数学已经够用，不需要 AI 确认）
                        
                        # 只有满足条件才调用 AI
                        if should_trigger_ai:
                            ai_result = ai_predictor.predict(sym, direction, ind, pd)
                        else:
                            ai_result = None  # 纯数学决策
                            log.info(f"🤖 {sym} 跳过 AI（评分{score}分，纯数学决策）")

                        # AI与数学信号冲突时降级观望
                        if ai_result:
                            ai_dir = ai_result.get("direction", "")
                            conflict = (
                                (direction == "LONG"  and ai_dir in ["做空", "震荡"]) or
                                (direction == "SHORT" and ai_dir in ["做多", "震荡"])
                            )
                            if conflict and ai_result.get("confidence", 0) > 70:
                                log.info(f"⏸️ {sym} AI与数学信号冲突，观望")
                                continue

                        # 开仓前再次检查持仓数（双重保险）
                        # 🐛 Bug 修复：API 是真相，本地是缓存
                        current_pos = get_all_positions()
                        api_count = sum(1 for p in current_pos if float(p.get("amount", 0)) != 0)
                        local_count = len(positions)
                        
                        # API 有数据时相信 API，否则用本地
                        if api_count > 0:
                            actual_count = api_count + opened_this_loop
                        else:
                            actual_count = local_count + opened_this_loop
                        
                        if actual_count >= CONFIG["max_positions"]:
                            log.info(f"⚠️ {sym} 已达最大持仓数 {actual_count}/{CONFIG['max_positions']}，跳过开仓")
                            continue
                        
                        entry = pd["price"]
                        tp_sl = calc_tp_sl(entry, direction, ind, pd)
                        pos = open_position(sym, direction, entry, score, tp_sl, regime, ai_result)
                        # 只有订单成功才记录持仓和冷却
                        if pos.get("order_result", {}).get("success", True):
                            positions.append(pos)
                            cooldown_manager.record(sym, direction)
                            save_positions(positions)
                            opened_this_loop += 1  # 累加本循环开仓数
                            log.info(f"✅ {sym} 开仓成功，当前持仓：{len(positions)}/{CONFIG['max_positions']}")
                        else:
                            # ✅ 2026-03-24 修复：失败也要记录冷却，防止循环重试刷屏
                            cooldown_manager.record(sym, direction)
                            log.error(f"❌ {sym} 开仓失败，已记录冷却 300 秒")

            # 刷新推送缓冲区（合并同一币种的信号）
            merged_signals = cooldown_manager.flush_push_buffer()
            for signal in merged_signals:
                _send_push_signal(signal)

            # ──────────────────────────────────
            # Step 6: 整点汇报（每小时一次，重启后自动补发）
            # ──────────────────────────────────
            current_hour = datetime.now().hour
            current_time = time.time()
            
            # 整点汇报：每小时第一次检查时触发 + 距离上次推送至少 30 分钟
            if current_hour != last_report_hour and (current_time - last_report_time) > 1800:
                # 整点汇报：每小时第一次检查时触发（不依赖 tick）
                hourly_report(positions, prices, indicators, circuit_breaker, fg_cache)
                last_report_hour = current_hour
                last_report_time = current_time  # 记录推送时间

            # 保存状态
            save_state({
                "last_update": datetime.now().isoformat(),
                "prices":      {k: v.get("price") for k, v in prices.items()},
                "positions":   len(positions),
                "daily_pnl":   circuit_breaker.daily_pnl,
                "fear_greed":  fg_cache,
                "tick":        scheduler.tick,
                "last_report_hour": last_report_hour,  # 保存整点汇报状态
                "last_report_time": last_report_time,
            })

        except Exception as e:
            log.error(f"主循环异常: {e}", exc_info=True)

        # 精确15秒间隔
        elapsed = time.time() - loop_start
        await asyncio.sleep(max(0, CONFIG["scan_interval"] - elapsed))


# ─────────────────────────────────────────────
if __name__ == "__main__":
    asyncio.run(main())
